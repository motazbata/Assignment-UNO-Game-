package game;

public class MyGame extends Game {

}
